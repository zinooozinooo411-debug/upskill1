import serverless from 'serverless-http';
import { createExpressApp } from '../../server/app.ts';
import { getDb } from '../../server/db.ts';

const app = createExpressApp();
const serverlessHandler = serverless(app);

export const handler = async (event: any, context: any) => {
  if (context) {
    context.callbackWaitsForEmptyEventLoop = false;
  }
  try {
    await getDb();
  } catch (err) {
    console.error('Failed to initialize database in Netlify Function handler:', err);
  }
  return serverlessHandler(event, context);
};

export default handler;
