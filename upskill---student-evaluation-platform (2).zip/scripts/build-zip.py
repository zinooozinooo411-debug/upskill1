import os
import zipfile

def create_zip():
    zip_filename = 'upskill-netlify-ready.zip'
    exclude_dirs = {
        'node_modules',
        '.git',
        'dist',
        '.vite',
        '__pycache__',
        '.idea',
        '.vscode',
        'coverage'
    }
    exclude_files = {
        zip_filename,
        '.DS_Store'
    }

    base_dir = os.path.abspath(os.getcwd())
    print(f"Creating {zip_filename} from {base_dir}...")

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(base_dir):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                if file in exclude_files or file.endswith('.pyc') or file.endswith('.log'):
                    continue
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, base_dir)
                zf.write(file_path, rel_path)
                # print(f"Added: {rel_path}")

    size_kb = os.path.getsize(zip_filename) / 1024
    print(f"Successfully created {zip_filename} ({size_kb:.1f} KB)")

    # Also copy to public/ so it gets bundled into dist/ for direct web download
    os.makedirs('public', exist_ok=True)
    import shutil
    shutil.copyfile(zip_filename, os.path.join('public', zip_filename))
    print(f"Copied to public/{zip_filename}")

if __name__ == '__main__':
    create_zip()
