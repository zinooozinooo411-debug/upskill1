import express from 'express';
import authRoutes from './routes/authRoutes.ts';
import studentRoutes from './routes/studentRoutes.ts';
import teacherRoutes from './routes/teacherRoutes.ts';
import adminRoutes from './routes/adminRoutes.ts';
import notificationRoutes from './routes/notificationRoutes.ts';
import { getDb } from './db.ts';

export function createExpressApp() {
  const app = express();

  app.use(express.json());

  // Database initialization middleware
  app.use(async (_req, _res, next) => {
    try {
      await getDb();
      next();
    } catch (err) {
      console.error('Database connection error in middleware:', err);
      next(err);
    }
  });

  // Normalize Netlify function path if present in URL
  app.use((req, _res, next) => {
    if (req.url.startsWith('/.netlify/functions/api')) {
      req.url = req.url.replace('/.netlify/functions/api', '') || '/';
    }
    next();
  });

  // Health check endpoint
  const healthHandler = (_req: express.Request, res: express.Response) => {
    res.json({
      status: 'healthy',
      service: 'upskill-api',
      timestamp: new Date().toISOString()
    });
  };
  app.get('/api/health', healthHandler);
  app.get('/health', healthHandler);

  // Mount routes with BOTH '/api/...' and '/...'
  // This guarantees compatibility whether Netlify forwards with or without the /api prefix
  app.use('/api/auth', authRoutes);
  app.use('/auth', authRoutes);

  app.use('/api/student', studentRoutes);
  app.use('/student', studentRoutes);

  app.use('/api/teacher', teacherRoutes);
  app.use('/teacher', teacherRoutes);

  app.use('/api/admin', adminRoutes);
  app.use('/admin', adminRoutes);

  app.use('/api/notifications', notificationRoutes);
  app.use('/notifications', notificationRoutes);

  return app;
}
