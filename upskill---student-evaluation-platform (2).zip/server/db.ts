import initSqlJs from 'sql.js';
import type { Database as SqlDatabase } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isServerless = Boolean(
  process.env.NETLIFY ||
  process.env.AWS_LAMBDA_FUNCTION_NAME ||
  process.env.LAMBDA_TASK_ROOT ||
  process.env.VERCEL
);

const WRITABLE_DB_PATH = isServerless
  ? path.resolve('/tmp', 'student_growth.sqlite')
  : path.resolve(process.cwd(), 'student_growth.sqlite');

let dbInstance: SqlDatabase | null = null;
let initPromise: Promise<SqlDatabase> | null = null;

function findSeedDbPath(): string | null {
  const candidatePaths = [
    path.resolve(process.cwd(), 'student_growth.sqlite'),
    path.resolve(__dirname, 'student_growth.sqlite'),
    path.resolve(__dirname, '../student_growth.sqlite'),
    path.resolve(__dirname, '../../student_growth.sqlite'),
  ];
  for (const p of candidatePaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }
  return null;
}

function findWasmPath(): string | null {
  const candidatePaths = [
    path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm'),
    path.resolve(__dirname, 'sql-wasm.wasm'),
    path.resolve(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm'),
    path.resolve(__dirname, '../../node_modules/sql.js/dist/sql-wasm.wasm'),
  ];
  for (const p of candidatePaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }
  return null;
}

export async function getDb(): Promise<SqlDatabase> {
  if (dbInstance) {
    return dbInstance;
  }
  if (initPromise) {
    return initPromise;
  }

  initPromise = (async () => {
    const wasmFile = findWasmPath();
    const SQL = await initSqlJs(
      wasmFile
        ? {
            locateFile: () => wasmFile,
          }
        : undefined
    );

    // If running in Netlify/Serverless, copy seed file to /tmp if not already there
    if (isServerless && !fs.existsSync(WRITABLE_DB_PATH)) {
      const seedPath = findSeedDbPath();
      if (seedPath && seedPath !== WRITABLE_DB_PATH) {
        try {
          const seedData = fs.readFileSync(seedPath);
          fs.writeFileSync(WRITABLE_DB_PATH, seedData);
          console.log(`Copied initial seed SQLite DB from ${seedPath} to ${WRITABLE_DB_PATH}`);
        } catch (e) {
          console.warn('Could not copy seed DB to /tmp, will initialize new DB:', e);
        }
      }
    }

    if (fs.existsSync(WRITABLE_DB_PATH)) {
      try {
        const fileBuffer = fs.readFileSync(WRITABLE_DB_PATH);
        dbInstance = new SQL.Database(fileBuffer);
        initSchema(dbInstance);
        return dbInstance;
      } catch (e) {
        console.error('Error reading existing DB file, creating fresh database:', e);
      }
    }

    // Fallback: create fresh database
    dbInstance = new SQL.Database();
    initSchema(dbInstance);
    saveDb();
    return dbInstance;
  })();

  return initPromise;
}

export function saveDb(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(WRITABLE_DB_PATH, buffer);
  } catch (err) {
    console.error(`Failed to save database to ${WRITABLE_DB_PATH}:`, err);
  }
}

export function queryAll<T = any>(sql: string, params: any[] = []): T[] {
  if (!dbInstance) throw new Error('Database not initialized');
  const stmt = dbInstance.prepare(sql);
  try {
    stmt.bind(params);
    const results: T[] = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject() as unknown as T);
    }
    return results;
  } finally {
    stmt.free();
  }
}

export function queryOne<T = any>(sql: string, params: any[] = []): T | null {
  const rows = queryAll<T>(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

export function run(sql: string, params: any[] = []): { changes: number } {
  if (!dbInstance) throw new Error('Database not initialized');
  dbInstance.run(sql, params);
  saveDb();
  return { changes: 1 };
}

export function getSetting(key: string, defaultValue: string = ''): string {
  const row = queryOne<{ value: string }>('SELECT value FROM system_settings WHERE key = ?', [key]);
  return row ? row.value : defaultValue;
}

export function setSetting(key: string, value: string): void {
  const existing = queryOne('SELECT key FROM system_settings WHERE key = ?', [key]);
  if (existing) {
    run('UPDATE system_settings SET value = ? WHERE key = ?', [value, key]);
  } else {
    run('INSERT INTO system_settings (key, value) VALUES (?, ?)', [key, value]);
  }
}

function initSchema(db: SqlDatabase): void {
  db.run(`PRAGMA foreign_keys = ON;`);
  db.run(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    INSERT OR IGNORE INTO system_settings (key, value) VALUES ('allow_registration', '0');

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT CHECK(role IN ('admin', 'teacher', 'student')) NOT NULL,
      subject TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feedback (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      teacher_id TEXT NOT NULL,
      subject TEXT NOT NULL,
      category TEXT DEFAULT 'Understanding' NOT NULL,
      strengths TEXT NOT NULL,
      areas_to_improve TEXT NOT NULL,
      personal_comment TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT,
      FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS goals (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      teacher_id TEXT NOT NULL,
      feedback_id TEXT,
      title TEXT NOT NULL,
      description TEXT,
      deadline TEXT,
      status TEXT CHECK(status IN ('not_started', 'in_progress', 'completed')) DEFAULT 'not_started',
      created_at TEXT NOT NULL,
      completed_at TEXT,
      FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (feedback_id) REFERENCES feedback(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS general_observations (
      id TEXT PRIMARY KEY,
      teacher_id TEXT NOT NULL,
      category TEXT DEFAULT 'General' NOT NULL,
      subject TEXT,
      observation TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS general_goals (
      id TEXT PRIMARY KEY,
      teacher_id TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      deadline TEXT,
      status TEXT DEFAULT 'active' NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS teacher_suggestions (
      id TEXT PRIMARY KEY,
      teacher_id TEXT NOT NULL,
      category TEXT NOT NULL,
      text TEXT NOT NULL,
      usage_count INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS recognitions (
      id TEXT PRIMARY KEY,
      teacher_id TEXT NOT NULL,
      student_id TEXT NOT NULL,
      category TEXT NOT NULL,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      read INTEGER DEFAULT 0,
      link TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);
}

export function resetToCleanProduction(): void {
  if (!dbInstance) return;
  dbInstance.run(`
    DELETE FROM notifications;
    DELETE FROM recognitions;
    DELETE FROM teacher_suggestions;
    DELETE FROM general_goals;
    DELETE FROM general_observations;
    DELETE FROM goals;
    DELETE FROM feedback;
    DELETE FROM users;
  `);
  saveDb();
}
