# منصة Upskill - Student Evaluation Platform (جاهزة للنشر على Netlify)

منصة تربوية متكاملة لمتابعة وتقييم وتطوير مهارات الطلاب، معدلة بالكامل لتعمل على **Netlify** كـ Single-Page Application (SPA) مع **Netlify Functions** خادمة لجميع الـ API endpoints وقاعدة بيانات SQLite مدمجة ومستمرة عبر `sql.js`.

---

## 🚀 النشر المباشر على Netlify (Deploying to Netlify)

### الطريقة الأولى: عبر GitHub / Git (موصى بها)
1. ارفع هذا المشروع إلى مستودع GitHub جديد.
2. ادخل على لوحة تحكم [Netlify](https://app.netlify.com) واضغط **"Add new site" > "Import an existing project"**.
3. اختر مستودع المشروع.
4. إعدادات البناء المضمنة في ملف `netlify.toml` سيتم تطبيقها تلقائيًا:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
   - **Functions directory**: `netlify/functions`
5. اضغط **Deploy Site**.

### الطريقة الثانية: عبر Netlify CLI
1. ثبّت أداة Netlify:
   ```bash
   npm install -g netlify-cli
   ```
2. قم بتسجيل الدخول:
   ```bash
   netlify login
   ```
3. انشر المشروع مباشرة:
   ```bash
   netlify deploy --build --prod
   ```

---

## 🔑 الحسابات الافتراضية الجاهزة للاختبار:

- **حساب الإدارة (Admin)**:
  - اسم المستخدم: `admin`
  - كلمة المرور: `password123`

- **حساب المعلم (Teacher)**:
  - اسم المستخدم: `teacher`
  - كلمة المرور: `password123`

- **حسابات الطلاب (Student)**:
  - اسم المستخدم: `student_tariq` | كلمة المرور: `password123`
  - اسم المستخدم: `student_khaled` | كلمة المرور: `password123`

---

## 🛠️ التشغيل والتطوير المحلي (Local Development)

```bash
# تثبيت الحزم
npm install

# تشغيل السيرفر المحلي
npm run dev
# سيعمل على http://localhost:3000
```
